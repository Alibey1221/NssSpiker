package com.example.nssspiker;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** OCR'dan gelen cumleyi seslendirmeye hazirlar: Turkce harfleri geri getirir, BUYUK HARF isimleri duzeltir. */
public class SpeechText {

    private static final Locale TR = new Locale("tr", "TR");

    // Oyunda gordugumuz ve tahmin ettigimiz cumlelerden kelime sozlugu. Sadece Turkce harfli kelimeler alinir.
    private static final String CANON =
            "Duvan bo\u015f alanda ald\u0131. F\u0131rsat ka\u00e7t\u0131. Duvan ileri \u00e7\u0131k\u0131yor. topu ileri g\u00f6nderdi... "
            + "\u0130nan\u0131lmaz bir gol ka\u00e7t\u0131! Son vuru\u015fu yapamad\u0131. Y\u00fcksek topun hedefi. kafas\u0131n\u0131 kullan\u0131yor. "
            + "topu harika ta\u015f\u0131yor... Ancak f\u0131rsat harcanm\u0131\u015f oldu. i\u00e7in iyi bir orta... "
            + "Ooo! Kale direkleri izin vermedi. i\u00e7in gol pozisyonu... Ama kafayla uzakla\u015ft\u0131r\u0131ld\u0131. "
            + "Enfes bir gol! \u015e\u0131k bir \u015fekilde kaleye b\u0131rakt\u0131. Top a\u011flarda! Gol! Harika bir vuru\u015f! "
            + "M\u00fckemmel bir bitirici vuru\u015f. Kaleciyi avlad\u0131. A\u011flar\u0131 havaland\u0131rd\u0131. Kaleci \u00e7aresiz! "
            + "Alt\u0131 pastan topu a\u011flara yollad\u0131. ata\u011fa kalk\u0131yor... Harika bir pas. Bo\u015f alan\u0131 iyi g\u00f6rd\u00fc. "
            + "Defans\u0131n arkas\u0131na sarkt\u0131. Ceza sahas\u0131na orta... H\u0131zl\u0131 bir kontra atak f\u0131rsat\u0131. "
            + "Direkten d\u00f6nd\u00fc! Dire\u011fi s\u0131y\u0131rd\u0131! \u00dcst direkten d\u0131\u015far\u0131 \u00e7\u0131kt\u0131. "
            + "Kaleci i\u00e7in kolay bir top. \u0130nan\u0131lmaz bir kurtar\u0131\u015f! K\u00f6t\u00fc bir vuru\u015f. "
            + "Topu da\u011flara ta\u015flara vurdu. Topu trib\u00fcnlere yollad\u0131. Serbest vuru\u015f! Penalt\u0131! K\u00f6\u015fe vuru\u015fu. "
            + "Hakem ofsayt bayra\u011f\u0131n\u0131 kald\u0131rd\u0131. Sar\u0131 kart! K\u0131rm\u0131z\u0131 kart! Oyundan at\u0131ld\u0131! "
            + "K\u00f6t\u00fc bir pas. Defans araya giriyor. Topu kapt\u0131rd\u0131. \u015fut \u00e7ekiyor. Ka\u00e7\u0131rd\u0131. Hakem d\u00fcd\u00fc\u011f\u00fc \u00e7ald\u0131.";

    private static final Map<String, String> WORDS = new HashMap<>();

    static {
        for (String w : CANON.split("[^\\p{L}]+")) {
            if (w.isEmpty()) continue;
            String lw = w.toLowerCase(TR);
            if (!lw.matches(".*[\u00e7\u011f\u0131\u00f6\u015f\u00fc].*")) continue;
            String key = LogTracker.norm(lw);
            if (!WORDS.containsKey(key)) WORDS.put(key, lw);
        }
    }

    public static String prepare(String s) {
        String[] parts = s.trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            int a = 0;
            int b = part.length();
            while (a < b && !Character.isLetter(part.charAt(a))) a++;
            while (b > a && !Character.isLetter(part.charAt(b - 1))) b--;
            String pre = part.substring(0, a);
            String core = part.substring(a, b);
            String post = part.substring(b);
            if (!core.isEmpty()) core = fixWord(core);
            out.append(pre).append(core).append(post).append(' ');
        }
        String r = out.toString().trim();
        return r.replaceAll("\\.{2,}", ".").replace("\u2026", ".");
    }

    private static String fixWord(String w) {
        if (w.length() >= 3 && w.equals(w.toUpperCase(TR))) {
            if (w.equals("NEWCAS")) return "Newcastle";
            return cap(w.toLowerCase(TR));
        }
        String canon = WORDS.get(LogTracker.norm(w));
        if (canon != null && !w.toLowerCase(TR).equals(canon)) {
            return Character.isUpperCase(w.charAt(0)) ? cap(canon) : canon;
        }
        return w;
    }

    private static String cap(String s) {
        return s.substring(0, 1).toUpperCase(TR) + s.substring(1);
    }
}
