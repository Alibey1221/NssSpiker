package com.example.nssspiker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 100;
    private SharedPreferences prefs;
    private EditText keyEt;
    private EditText modelEt;
    private EditText headerEt;
    private EditText topEt;
    private EditText botEt;
    private TextView logTv;
    private Speaker testSpeaker;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            String head = CaptureService.running ? "DURUM: calisiyor\n\n" : "DURUM: durdu\n\n";
            logTv.setText(head + CaptureService.getLog());
            ui.postDelayed(this, 700);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("nss", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("NSS Spiker");
        title.setTextSize(24);
        root.addView(title);

        keyEt = addField(root, "fish.audio API anahtari", "key", "", true);
        modelEt = addField(root, "Ses modeli ID", "model", "e9fa58c1e07442daa9cc8b3c7930346e", false);
        headerEt = addField(root, "Model basligi (ucretsiz: s2.1-pro-free)", "header", "s2.1-pro-free", false);
        topEt = addField(root, "Okunacak alanin ustu (ekran yuksekliginin %)", "top", "33", false);
        botEt = addField(root, "Okunacak alanin alti (%)", "bot", "74", false);

        root.addView(button("Ayarlari kaydet", v -> {
            save();
            CaptureService.log("Ayarlar kaydedildi.");
        }));
        root.addView(button("Ses testi", v -> {
            save();
            if (testSpeaker != null) testSpeaker.shutdown();
            testSpeaker = new Speaker(this, prefs.getString("key", ""), prefs.getString("model", ""),
                    prefs.getString("header", ""), CaptureService::log);
            testSpeaker.say(SpeechText.prepare("Enfes bir gol! Top a\u011flarda!"));
            CaptureService.log("Ses testi istendi, birkac saniye bekle.");
        }));
        root.addView(button("Baslat (ekran okuma)", v -> {
            save();
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        }));
        root.addView(button("Durdur", v -> stopService(new Intent(this, CaptureService.class))));

        logTv = new TextView(this);
        logTv.setTextSize(12);
        logTv.setPadding(0, pad, 0, 0);
        root.addView(logTv);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private EditText addField(LinearLayout root, String label, String key, String def, boolean secret) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setPadding(0, 24, 0, 0);
        root.addView(tv);
        EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(prefs.getString(key, def));
        if (secret) et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(et);
        return et;
    }

    private Button button(String label, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setOnClickListener(l);
        return bt;
    }

    private void save() {
        prefs.edit()
                .putString("key", keyEt.getText().toString().trim())
                .putString("model", modelEt.getText().toString().trim())
                .putString("header", headerEt.getText().toString().trim())
                .putString("top", topEt.getText().toString().trim())
                .putString("bot", botEt.getText().toString().trim())
                .apply();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("rc", resultCode);
            i.putExtra("data", data);
            startForegroundService(i);
        } else {
            CaptureService.log("Ekran yakalama izni verilmedi.");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(refresh);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(refresh);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (testSpeaker != null) testSpeaker.shutdown();
        super.onDestroy();
    }
}
