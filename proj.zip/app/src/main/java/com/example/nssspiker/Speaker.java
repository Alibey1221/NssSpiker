package com.example.nssspiker;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Cumleyi fish.audio'dan mp3 olarak alir, telefona kaydeder (ayni cumle ikinci kez internetsiz calar)
 * ve sirayla calar. Ses uretme ve calma ayri kanallarda calisir, boylece siradaki cumle onceden hazirlanir.
 */
public class Speaker {

    public interface Logger {
        void log(String s);
    }

    private static class ApiException extends IOException {
        final int code;

        ApiException(int code, String msg) {
            super("HTTP " + code + ": " + msg);
            this.code = code;
        }
    }

    private final String apiKey;
    private final String modelId;
    private final String modelHeader;
    private final Logger logger;
    private final File dir;
    private final BlockingQueue<String> pending = new LinkedBlockingQueue<>();
    private final BlockingQueue<File> ready = new ArrayBlockingQueue<>(3);
    private volatile boolean running = true;
    private final Thread fetchThread;
    private final Thread playThread;

    public Speaker(Context ctx, String apiKey, String modelId, String modelHeader, Logger logger) {
        this.apiKey = apiKey;
        this.modelId = modelId;
        this.modelHeader = modelHeader;
        this.logger = logger;
        this.dir = new File(ctx.getFilesDir(), "tts");
        this.dir.mkdirs();
        fetchThread = new Thread(this::fetchLoop, "tts-fetch");
        playThread = new Thread(this::playLoop, "tts-play");
        fetchThread.start();
        playThread.start();
    }

    /** Cumleyi siraya koyar. Kuyruk sismisse en eskileri atar ki anlatim olayin cok gerisinde kalmasin. */
    public void say(String text) {
        while (pending.size() >= 4) pending.poll();
        pending.offer(text);
    }

    public void shutdown() {
        running = false;
        fetchThread.interrupt();
        playThread.interrupt();
    }

    private void fetchLoop() {
        while (running) {
            try {
                String text = pending.take();
                File f = new File(dir, sha1(modelId + "|" + text) + ".mp3");
                if (!f.exists() || f.length() == 0) {
                    byte[] audio = fetchWithRetry(text);
                    if (audio == null) continue;
                    File tmp = new File(dir, f.getName() + ".tmp");
                    try (FileOutputStream o = new FileOutputStream(tmp)) {
                        o.write(audio);
                    }
                    if (!tmp.renameTo(f)) continue;
                    logger.log("Ses uretildi ve kaydedildi: " + text);
                }
                ready.put(f);
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                logger.log("Ses hazirlama hatasi: " + e);
            }
        }
    }

    private byte[] fetchWithRetry(String text) throws InterruptedException {
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                return fetch(text);
            } catch (ApiException e) {
                logger.log("fish.audio hatasi: " + e.getMessage());
                if (e.code == 401 || e.code == 402 || e.code == 400 || e.code == 422) return null;
            } catch (IOException e) {
                logger.log("Baglanti hatasi: " + e);
            }
            Thread.sleep(800);
        }
        return null;
    }

    private byte[] fetch(String text) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.fish.audio/v1/tts").openConnection();
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(40000);
            c.setRequestProperty("Authorization", "Bearer " + apiKey);
            c.setRequestProperty("Content-Type", "application/json");
            if (!modelHeader.isEmpty()) c.setRequestProperty("model", modelHeader);
            String body;
            try {
                JSONObject j = new JSONObject();
                j.put("text", text);
                j.put("reference_id", modelId);
                j.put("format", "mp3");
                j.put("language", "tr");
                body = j.toString();
            } catch (Exception e) {
                throw new IOException(e);
            }
            try (OutputStream o = c.getOutputStream()) {
                o.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            if (code != 200) {
                String err = "";
                InputStream es = c.getErrorStream();
                if (es != null) err = new String(readAll(es), StandardCharsets.UTF_8);
                throw new ApiException(code, err);
            }
            return readAll(c.getInputStream());
        } finally {
            c.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = i.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }

    private void playLoop() {
        while (running) {
            try {
                play(ready.take());
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                logger.log("Calma hatasi: " + e);
            }
        }
    }

    private void play(File f) throws Exception {
        final CountDownLatch done = new CountDownLatch(1);
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnCompletionListener(m -> done.countDown());
            mp.setOnErrorListener((m, what, extra) -> {
                done.countDown();
                return true;
            });
            mp.prepare();
            mp.start();
            done.await(30, TimeUnit.SECONDS);
        } finally {
            mp.release();
        }
    }

    private static String sha1(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder();
        for (byte x : d) b.append(String.format("%02x", x));
        return b.toString();
    }
}
