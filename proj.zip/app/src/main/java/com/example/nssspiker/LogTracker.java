package com.example.nssspiker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Ekrandaki kayan yorum listesinden yalnizca YENI satirlari bulur.
 * Android'e bagimli degil, bilgisayarda test edilebilir.
 */
public class LogTracker {

    public static class Row {
        public final String text;
        public final String norm;

        public Row(String text) {
            this.text = text;
            this.norm = norm(text);
        }
    }

    public static class Parsed {
        public final List<Row> rows = new ArrayList<>();
        public boolean sawStart = false;

        public boolean listVisible() {
            return sawStart || !rows.isEmpty();
        }
    }

    private static final String[] IGNORE = {"basla", "caliskanlik", "odak", "enerji", "bitirme"};
    private static final long COOLDOWN_MS = 2500;

    private final List<Row> history = new ArrayList<>();
    private List<Row> pending = new ArrayList<>();
    private boolean seeded = false;
    private int warmup = 0;
    private int sinceStart = 1000;
    private int startStreak = 0;
    private boolean newMatchArmed = false;
    private final HashMap<String, Long> lastSpoken = new HashMap<>();

    /** Harfleri sadelestirir: buyuk/kucuk harf, Turkce harf ve noktalama farki olmaz. */
    public static String norm(String s) {
        StringBuilder b = new StringBuilder();
        boolean lastSpace = true;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\u0131': case '\u0130': case 'I': case 'i': c = 'i'; break;
                case '\u015f': case '\u015e': c = 's'; break;
                case '\u011f': case '\u011e': c = 'g'; break;
                case '\u00fc': case '\u00dc': c = 'u'; break;
                case '\u00f6': case '\u00d6': c = 'o'; break;
                case '\u00e7': case '\u00c7': c = 'c'; break;
                default: c = Character.toLowerCase(c);
            }
            if (Character.isLetterOrDigit(c)) {
                b.append(c);
                lastSpace = false;
            } else if (!lastSpace) {
                b.append(' ');
                lastSpace = true;
            }
        }
        return b.toString().trim();
    }

    /** OCR'dan gelen ham satirlari (yukaridan asagiya) temizleyip satir listesine cevirir. */
    public static Parsed parse(List<String> raw) {
        Parsed p = new Parsed();
        for (String line : raw) {
            String t = line.trim().replaceFirst("^\\d{1,3}\\s+", "");
            String n = norm(t);
            if (n.length() < 3) continue;
            if (n.matches("[0-9 ]+")) continue;
            if (isStart(n)) {
                p.sawStart = true;
                continue;
            }
            boolean ignore = false;
            for (String s : IGNORE) if (n.equals(s)) ignore = true;
            if (ignore) continue;
            p.rows.add(new Row(t));
        }
        return p;
    }

    /** "Basla" satiri (OCR bir harfi yanlis okusa da). */
    static boolean isStart(String n) {
        return n.length() <= 6 && lev(n, "basla") <= 1;
    }

    static boolean same(String a, String b) {
        if (a.equals(b)) return true;
        int m = Math.max(a.length(), b.length());
        if (m < 8) return false;
        return 1.0 - (double) lev(a, b) / m >= 0.8;
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }

    /**
     * cur icinde, gecmise (history) gore yeni olan satirlar.
     * Gecmisin son satirlariyla ekrandaki satirlari sirayi bozmadan eslestirir (LCS);
     * son eslesen satirdan SONRAKI satirlar yenidir. OCR bir satiri kacirsa ya da bozarsa
     * eski satirlar yeni sanilmaz.
     */
    static List<Row> freshRows(List<Row> hist, List<Row> cur) {
        int c = cur.size();
        if (hist.isEmpty()) return new ArrayList<>(cur);
        if (c == 0) return new ArrayList<>();
        int n = Math.min(hist.size(), 12);
        List<Row> h = hist.subList(hist.size() - n, hist.size());
        int[][] dp = new int[n + 1][c + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= c; j++) {
                if (same(h.get(i - 1).norm, cur.get(j - 1).norm)) dp[i][j] = dp[i - 1][j - 1] + 1;
                else dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
        if (dp[n][c] >= Math.min(2, n)) {
            int i = n;
            int j = c;
            int anchor = -1;
            while (i > 0 && j > 0) {
                if (dp[i][j - 1] == dp[i][j]) { j--; continue; }
                if (dp[i - 1][j] == dp[i][j]) { i--; continue; }
                anchor = j - 1;
                break;
            }
            return new ArrayList<>(cur.subList(anchor + 1, c));
        }
        // Ortusme yok (ekran degismis olabilir): gecmiste hic bulunmayan satirlari yeni say.
        List<Row> out = new ArrayList<>();
        for (Row r : cur) {
            boolean seen = false;
            for (Row q : h) {
                if (same(q.norm, r.norm)) {
                    seen = true;
                    break;
                }
            }
            if (!seen) out.add(r);
        }
        return out;
    }

    /** Bir ekran karesini isler, seslendirilecek (onaylanmis) yeni satirlari dondurur. */
    public synchronized List<String> onFrame(Parsed p, long now) {
        List<String> out = new ArrayList<>();
        if (!p.listVisible()) return out;
        List<Row> cur = p.rows;

        if (!seeded) {
            seeded = true;
            history.clear();
            if (p.sawStart) {
                startStreak = 1;
                sinceStart = 0;
            } else {
                // Maci ortasinda actik: ekrandakiler eski, sessizce kaydet.
                sinceStart++;
                history.addAll(cur);
                warmup = 4; // ilk karelerde OCR bir satiri kacirmis olabilir: dolu gorunumu al
                return out;
            }
        } else if (warmup > 0 && !p.sawStart) {
            warmup--;
            sinceStart++;
            if (cur.size() >= history.size()) {
                history.clear();
                history.addAll(cur);
            }
            return out;
        } else if (p.sawStart) {
            // Yeni mac: "Basla" uzun suredir yokken ardisik 3 karede gorunurse.
            if (startStreak == 0 && sinceStart >= 6) newMatchArmed = true;
            startStreak++;
            sinceStart = 0;
            if (newMatchArmed && startStreak >= 3) {
                newMatchArmed = false;
                history.clear();
                pending = new ArrayList<>();
            }
        } else {
            startStreak = 0;
            sinceStart++;
            newMatchArmed = false;
        }

        List<Row> fresh = freshRows(history, cur);
        if (fresh.isEmpty()) {
            pending = new ArrayList<>();
            return out;
        }

        // Bir satir, arka arkaya iki karede gorulmeden okunmaz (yarim kesik yazilara karsi).
        int k = 0;
        while (k < pending.size() && k < fresh.size()
                && same(pending.get(k).norm, fresh.get(k).norm)) {
            k++;
        }
        if (k > 0) {
            for (int i = 0; i < k; i++) {
                Row r = fresh.get(i);
                Long t = lastSpoken.get(r.norm);
                if (t == null || now - t > COOLDOWN_MS) out.add(r.text);
                lastSpoken.put(r.norm, now);
                history.add(r);
            }
            while (history.size() > 30) history.remove(0);
            pending = new ArrayList<>(fresh.subList(k, fresh.size()));
        } else {
            pending = new ArrayList<>(fresh);
        }
        return out;
    }
}
