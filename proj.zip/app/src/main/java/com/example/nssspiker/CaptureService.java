package com.example.nssspiker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.view.WindowManager;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Ekrani yakalar, yorum listesini okur, yeni satirlari seslendirir. */
public class CaptureService extends Service {

    private static final StringBuilder LOG = new StringBuilder();
    public static volatile boolean running = false;

    /** En yeni satir en ustte. */
    public static synchronized void log(String s) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        LOG.insert(0, t + "  " + s + "\n");
        if (LOG.length() > 6000) LOG.setLength(5000);
    }

    public static synchronized String getLog() {
        return LOG.toString();
    }

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private Speaker speaker;
    private TextRecognizer recognizer;
    private final LogTracker tracker = new LogTracker();
    private float cropTop = 0.33f;
    private float cropBottom = 0.74f;
    private volatile boolean stopping = false;
    private String lastDump = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        startForegroundNow();
        int rc = intent.getIntExtra("rc", 0);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = (Intent) intent.getParcelableExtra("data");
        }
        if (data == null) {
            log("Ekran izni verisi gelmedi.");
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            setup(rc, data);
            running = true;
            log("Ekran okuma basladi. Oyuna gecebilirsin.");
        } catch (Exception e) {
            log("Baslatilamadi: " + e);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startForegroundNow() {
        NotificationChannel ch = new NotificationChannel("nss", "NSS Spiker", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        Notification n = new Notification.Builder(this, "nss")
                .setContentTitle("NSS Spiker calisiyor")
                .setContentText("Ekran okunuyor, yorumlar seslendiriliyor")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    private static float parseF(String s, float def) {
        try {
            return Float.parseFloat(s.trim().replace(',', '.'));
        } catch (Exception e) {
            return def;
        }
    }

    private void setup(int rc, Intent data) {
        SharedPreferences p = getSharedPreferences("nss", MODE_PRIVATE);
        String apiKey = p.getString("key", "").trim();
        String model = p.getString("model", "").trim();
        String header = p.getString("header", "").trim();
        cropTop = parseF(p.getString("top", "33"), 33f) / 100f;
        cropBottom = parseF(p.getString("bot", "74"), 74f) / 100f;
        if (apiKey.isEmpty() || model.isEmpty()) {
            throw new IllegalStateException("API anahtari veya ses modeli ID'si bos");
        }
        speaker = new Speaker(this, apiKey, model, header, CaptureService::log);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        thread = new HandlerThread("capture");
        thread.start();
        handler = new Handler(thread.getLooper());

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(rc, data);
        // Android 14+ icin zorunlu: sanal ekrandan once callback kaydedilir.
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                if (!stopping) stopSelf();
            }
        }, handler);

        Rect b = getSystemService(WindowManager.class).getMaximumWindowMetrics().getBounds();
        float s = Math.min(1f, 800f / b.width());
        int w = Math.round(b.width() * s);
        int h = Math.round(b.height() * s);
        int dpi = getResources().getConfiguration().densityDpi;
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("nss-spiker", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        handler.postDelayed(tick, 400);
        log("Yakalama boyutu " + w + "x" + h + ", okunan alan ekranin %"
                + Math.round(cropTop * 100) + " - %" + Math.round(cropBottom * 100) + " arasi.");
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (stopping) return;
            try {
                processFrame();
            } catch (Throwable t) {
                log("Okuma hatasi: " + t);
            }
            if (!stopping) handler.postDelayed(this, 450);
        }
    };

    private void processFrame() throws Exception {
        Image img = reader.acquireLatestImage();
        if (img == null) return;
        Bitmap crop;
        try {
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int pixelStride = pl.getPixelStride();
            int rowPadding = pl.getRowStride() - pixelStride * img.getWidth();
            Bitmap full = Bitmap.createBitmap(img.getWidth() + rowPadding / pixelStride,
                    img.getHeight(), Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            int top = Math.round(img.getHeight() * cropTop);
            int hh = Math.min(Math.round(img.getHeight() * cropBottom), img.getHeight()) - top;
            crop = Bitmap.createBitmap(full, 0, top, img.getWidth(), hh);
            full.recycle();
        } finally {
            img.close();
        }

        Text text = Tasks.await(recognizer.process(InputImage.fromBitmap(crop, 0)), 4, TimeUnit.SECONDS);
        final int ch = crop.getHeight();
        crop.recycle();

        List<Text.Line> lines = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) lines.addAll(b.getLines());
        Collections.sort(lines, (x, y) -> {
            Rect rx = x.getBoundingBox();
            Rect ry = y.getBoundingBox();
            int ax = rx == null ? 0 : rx.centerY();
            int ay = ry == null ? 0 : ry.centerY();
            return Integer.compare(ax, ay);
        });
        List<String> raw = new ArrayList<>();
        for (Text.Line l : lines) {
            Rect r = l.getBoundingBox();
            // Alanin ust/alt kenarinda yarim kesilmis satirlari atla.
            if (r != null && (r.top < 6 || r.bottom > ch - 6)) continue;
            raw.add(l.getText());
        }

        LogTracker.Parsed parsed = LogTracker.parse(raw);
        StringBuilder dump = new StringBuilder();
        for (LogTracker.Row r : parsed.rows) dump.append(r.text).append(" | ");
        String d = (parsed.sawStart ? "[Basla] " : "") + dump;
        if (!d.equals(lastDump)) {
            lastDump = d;
            log("Ekran: " + d);
        }

        List<String> say = tracker.onFrame(parsed, System.currentTimeMillis());
        for (String s : say) {
            String spoken = SpeechText.prepare(s);
            log("SES: " + spoken);
            speaker.say(spoken);
        }
    }

    @Override
    public void onDestroy() {
        stopping = true;
        running = false;
        try { if (handler != null) handler.removeCallbacksAndMessages(null); } catch (Throwable ignored) { }
        try { if (display != null) display.release(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) { }
        try { if (speaker != null) speaker.shutdown(); } catch (Throwable ignored) { }
        try { if (recognizer != null) recognizer.close(); } catch (Throwable ignored) { }
        if (thread != null) thread.quitSafely();
        log("Durduruldu.");
        super.onDestroy();
    }
}
